<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT empId, name, email, phoneNum, langId, projId, clientId FROM employeedata WHERE empId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$langDB = $row["langId"];
	$projDB = $row["projId"];
	$clientDB = $row["projId"];
	$empIdDB = $row["empId"];
	
	echo "<html>";
	echo "<head>";
	echo "	<title>"Employees"</title>";
	echo "		<meta charset='UTF-8'>";
	echo "		<link rel='stylesheet' type='text/css' href='CSS/EmployeeLayout.css'>";
	echo "		<script language='Javascript' type='text/javascript' src='Javascript/Employees.js'></script>";
	echo "</head>";
	echo "<body>";
	echo "	<div class='titleRegion'>";
	echo "		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href=\"index.php\";'>Back</button>\n";
  	echo "		<h1>"Employees"</h1>";
	echo "	</div>";
	
	echo "<div class='clearfix'>";
 	echo "<div class='column menu'>";
    echo "	<ul>";
    echo "  		<li onclick='displayItem(0);'>Add Employee</li>";
    echo "  		<li onclick='displayItem(1);'>Edit Employee</li>";
    echo "	</ul>";
  	echo "</div>";
	
	
?>