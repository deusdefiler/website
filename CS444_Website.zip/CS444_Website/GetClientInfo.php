<?php
	include("configDB.php");
?>

<?php
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }	
	
	$query = "SELECT name, email, phoneNum, address FROM Clients";
	$result = $db->query($query);		
	$numRow = $result->num_rows;
	$returnStr = $numRow."#";
	for ($i=0; $i<$numRow; $i++)
	{
		$row = $result->fetch_assoc();
		$returnStr = $returnStr.$row['name'].":".$row['email'].":".$row['phoneNum'].":".$row['address']."&";
	}
	
	echo $returnStr;

	$db->close();
?>