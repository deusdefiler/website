<?php
	include ("configDB.php");
?>
<?php
	function Back2MainPage($site)
	{
		echo '<script type="text/javascript">';
		echo 'alert("Employee Added Successfully.");';
		echo 'window.location.href="'.$site.'";';
		echo '</script>';
	}	
?>
<?php
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$db->set_charset("utf8");
	$empId = $db->real_escape_string($_POST['EmpSel']);
	
	if ($_POST['EmailBox']) $email = $db->real_escape_string($_POST['EmailBox']);
	else $email = "";
	
	if ($_POST['NameBox']) $clientName = $db->real_escape_string($_POST['NameBox']);
	else $empName = "";
	
	if ($_POST['PhoneBox']) $phone = $db->real_escape_string($_POST['PhoneBox']);
	else $phone = "";
	
	if ($_POST['LanguageBox']) $lang = $db->real_escape_string($_POST['LanguageBox']);
	else $lang = "";
	
	$query = "SELECT empId FROM employeedata WHERE name='".$empName."' OR email='".$email."'";
	$result = $db->query($query);	
	$numRows = $result->num_rows;
	
	if ($numRows == 0)
	{
		$result = $db->query("INSERT INTO employeedata (name, email, phoneNum, langId) VALUES ('$empName', '$email', '$phone', '$lang')");
		$empId = $db->insert_id;	
	}
	else
	{
		$row = $result->fetch_assoc();
		$empId = $row["empId"];
	}
	
	Back2MainPage("index.php");
	
	$db->close();
?>