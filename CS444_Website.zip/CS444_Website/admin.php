<?php
	function TransfterToSite($site)
	{
		echo '<script type="text/javascript">';
		echo '		window.location.href="'.$site.'";';
		echo '</script>';
	}	
?>
<?php 
	session_start();
	if (isset($_SESSION['userId']))
	{
		$currUserID = $_SESSION['userId'];
	}
	else
	{
		TransfterToSite("logout.php");
	}
?>		
<!DOCTYPE html>
<html>
<head>
	<title>Software Employee Database</title>
	<meta charset="UTF-8">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script language='Javascript' type='text/javascript' src='Javascript/AdminPage.js'></script>
	<link rel="stylesheet" type="text/css" href="CSS/AdminLayout.css">
</head>

<body>
	<div class="titleRegion">
		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href="logout.php";'>User Portal</button>
  		<h1>Admin Portal</h1>
	</div>

	<div id="MainDiv">
		<div class="clearfix">
		 	<div class="column menu">
		    	<ul>
		      		<li id="btn1" onclick="GetClientsList();">View Clients</li>
		      		<li id="btn2" onclick="DisplayAddClient();">Add Client</li>
		      		<li id="btn3" onclick="displayItem(2);">Edit Client</li>
			  		<li id="btn4" onclick="displayItem(3);">Add Employee</li>
			  		<li id="btn5" onclick="displayItem(3);">Edit Employeee</li>
		    	</ul>
		  	</div>
			<div id="DisplayArea" class="column info">
		  		<div class='column info'>
					<div id='ViewClientsBlock' class='inputBlock'>
					</div>
					
					<div id='AddClientBlock' class='inputBlock'>
						<div id='ClientSpan'>
							<label class="clientInfoLabel">Name:</label>
							<input type="text" id="ClientBox" name="ClientBox">
						</div>
						<div>
							<span id='EmailSpan'>
								<label class="clientInfoLabel">Email:</label>
								<input type="email" id="EmailBox" name="EmailBox">
							</span>
							<span id='PhoneSpan'>
								<label class="clientInfoLabel">Phone:</label>
								<input type="text" id="PhoneBox" name="PhoneBox">
							</span>
						</div>
						<div id='AddressSpan'>
							<label >Address:</label><br>
							<textarea id="AddressBox" name="AddressBox" rows="4" cols="50" style='disabled: true;'></textarea>
						</div>
						<div>
							<button id="AddClientBtn" onclick="SubmitAddClient();">Submit</button>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</div>
</body>
</html>