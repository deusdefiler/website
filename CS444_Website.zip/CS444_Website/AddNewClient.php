<?php
	function Back2MainPage($site)
	{
		echo '<script type="text/javascript">';
		echo 'alert("Client addition successful!\nRerouting to main page.");';
		echo 'window.location.href="'.$site.'";';
		echo '</script>';
	}	
?>
<?php	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed."; exit; }

	$db->set_charset("utf8");
	
	if ($_POST['ClientBox']) $clientName = filter_var($db->real_escape_string($_POST['ClientBox']), FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
	else $clientName = "";

	if ($_POST['EmailBox']) $email = filter_var($db->real_escape_string($_POST['EmailBox']), FILTER_SANITIZE_STRING);
	else $email = "";
	
	if ($_POST['PhoneBox']) $phone = filter_var($db->real_escape_string($_POST['PhoneBox']), FILTER_SANITIZE_STRING);
	else $phone = "";

	if ($_POST['AddressBox']) $address = $db->real_escape_string($_POST['AddressBox']);
	else $address = "";
	
	$returnStr=0;
	
	$query = "SELECT clientId FROM clients LEFT JOIN Projects ON clients.clientId=Projects.client";
	$result = $result = $db->query($query);	
	$numRows = $result->num_rows;
	if ($numRows == 0)
	{
		$prep = $db->prepare("INSERT INTO clients (name, email, phoneNum, address) VALUES (?, ?, ?, ?)");
		$prep->bind_param("ssss", $clientName, $email, $phone, $address);
		$prep->execute();
	}
	else
	{
		$returnStr = 1;
	}
	echo $returnStr;
	$db->close();
?>