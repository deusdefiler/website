<?php
	$siteName="Software Employee Database";
	$cookieName="CTS_657";
	$server="localhost";
	$username="root";
	$password="";
	$dbName="employees";
	$dbPrefix="";
	$siteDir = dirname(__FILE__);
	$currUserID = 1;
?>