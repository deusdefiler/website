<?php
	$siteName="Software Employee Database";
	$cookieName="CTS_657";
	$server="localhost";
	$username="root";
	$password="";
	$dbName="employees";
	$dbPrefix="";
	$siteDir = dirname(__FILE__);
	$currUserID = 1;
	$conn= mysqli_connect($server, $username, $password, $dbName);
	if (empty($conn)){
		die("Connection Failed: ".mysqli_connect_error);
?>