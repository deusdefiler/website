<!DOCTYPE html>
<html>
<head>
	<title>Software Employee Database</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="CSS/MainLayout.css">
	<link rel="stylesheet" type="text/css" href="CSS/overlayout.css">
	<script language='Javascript' type='text/javascript' src='Javascript/MainPage.js'></script>
</head>

<body>
	<div id='AdminLoginOverlay' class='overlay'>
		<a href='javascript:void(0)' class='closebtn' onclick='closeSearch()'><img src='Images/close_window.png' /></a>
		<form action='Login.php' method='POST'>	
			<div class='overlay-content'>
				<span>Admin Login</span>
				<span id='UserNameSpan'>
					<label class="clientInfoLabel">Name:</label>
					<input type="text" id="uname" name="uname">
				</span>
				<span id='PasswordSpan'>
					<label class="clientInfoLabel">Password:</label>
					<input type="password" id="password" name="password">
				</span>
			</div>	
			<input id='adminOKBtn' type='submit' value='Send'>
		</form>
	</div>
	
	<div class="titleRegion">
  		<h1>Software Employee Database</h1>
	</div>
	
	<div id="MainDiv">		
		<table id="layoutMainTable" class="layout">
			<tr>
				<td id="Menu1" class="menuItem" onclick="MenuItem_OnClick('1')" onmouseover="MenuItem_OnMouseOver('1')" onmouseout="MenuItem_OnMouseOut('1')">
					<div class="imgDiv">
						<img id="MenuImg1" class="MenuImg" src="Images/employeesmeeting.jpg">
					</div>
					<div id="MenuText1" class="MenuText">View Employees</div>
				</td>
			</tr>
			<tr>
				<td id="Menu2" class="menuItem" onclick="MenuItem_OnClick('2')" onmouseover="MenuItem_OnMouseOver('2')" onmouseout="MenuItem_OnMouseOut('2')">
					<div class="imgDiv">
						<img id="MenuImg2" class="MenuImg" src="Images/clientsmeeting.jpg">
					</div>
					<div id="MenuText2" class="MenuText">View Clients</div>
				</td>
			</tr>
		</table>
		<button style='float: right' id='AdminBtn' type='button' name='AdminBtn' onclick='AdminBtn_OnClick();'>Admin</button>
</body>
</html>