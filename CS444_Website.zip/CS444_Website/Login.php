<?php
	function TransfterToSite($site)
	{
		echo '<script type="text/javascript">';
		echo '		window.location.href="'.$site.'";';
		echo '</script>';
	}	
?>
<?php
	session_start();
?>
<?php
	if (isset($_POST['uname']) && isset($_POST['password']))
	{
		$uname = $_POST['uname'];
		$password = $_POST['password'];
		
		$db = new mysqli($server, $username, $password, $dbName);
		if (mysqli_connect_errno()) { echo "Connection Failed!"; exit; }
		$db->set_charset("utf8");
		
		$uname = $db->real_escape_string($uname);
		$password = $db->real_escape_string($password);

		$result = $db->query("SELECT * FROM Users WHERE username='".$uname."' AND password='".sha1($password)."'");
		if ($result->num_rows)
		{
			$row = $result->fetch_assoc();			
			$_SESSION['userId'] = $row['userId'];
			TransfterToSite("Admin.php");
		}
		else 
		{
			TransfterToSite("index.php");
			session_unset();
			session_destroy();
		}
		$db->close();
	}
?>