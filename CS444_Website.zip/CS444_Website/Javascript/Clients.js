function displayItem(n)
{
	for (i=0; i<4; i++)
	{
		if (i == n)
			document.getElementById("item"+i).style.display = "block";
		else
			document.getElementById("item"+i).style.display = "none";
	}
}
function DisplayAddClient()
{
	document.getElementById("NameBox").value = "";
	document.getElementById("EmailBox").value = "";
	document.getElementById("PhoneBox").value = "";
	document.getElementById("AddressBox").value = "";
	document.getElementById("ViewClientBlock").style.display = "none";
	document.getElementById("AddClientBlock").style.display = 'block';
}

function SubmitAddClient()
{
	var cname = document.getElementById("CNameBox").value;
	var email = document.getElementById("EmailBox").value;
	var phone = document.getElementById("PhoneBox").value;
	var addr = document.getElementById("AddressBox").value;
	
	xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function()
  	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    	{	
			var str = xmlhttp.responseText;
			
			if (str == "0")	
			{	
				if(confirm("Client successfully added."))
				{
			    	window.location.reload();  
				}
			}
			else if (str == "1")
			{	
				if(confirm("Client already exists."))
				{
			    	window.location.reload();  
				}
			}
			else alert("Undefined: " + str);
		}
  	}	

	xmlhttp.open("POST","AddNewClient.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("NameBox="+cname+"&EmailBox="+email+"&PhoneBox="+phone+"&AddressBox="+encodeURIComponent(lang));
}