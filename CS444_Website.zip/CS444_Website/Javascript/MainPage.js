function MenuItem_OnMouseOver(num) 
{
	document.getElementById("Menu"+num).style.backgroundColor = "#999999";
}

function MenuItem_OnMouseOut(num) 
{
	document.getElementById("Menu"+num).style.backgroundColor = "blue";
}

function MenuItem_OnClick(num) 
{
	window.location.href = "Employees.php?num="+num;
}

function openSearch() 
{
    document.getElementById("InfoRequestOverlay").style.height = "680px";
	document.getElementById("okbtn").style.display = "block";
}

function closeSearch() 
{
    document.getElementById("InfoRequestOverlay").style.height = "0px";
    document.getElementById("AdminLoginOverlay").style.height = "0px";
	document.getElementById("okbtn").style.display = "none";
}

function AdminBtn_OnClick() 
{
    document.getElementById("AdminLoginOverlay").style.height = "350px";
}