function MenuItem_OnMouseOver(num) 
{
	document.getElementById("Menu"+num).style.backgroundColor = "#f7f7f7";
}

function MenuItem_OnMouseOut(num) 
{
	document.getElementById("Menu"+num).style.backgroundColor = "blue";
}

function MenuItem_OnClick(1) 
{
	window.location.href = "Employees.php";
}

function MenuItem_OnClick(2) 
{
	window.location.href = "Clients.php";
}

function openSearch() 
{
	document.getElementById("okbtn").style.display = "block";
}

function closeSearch() 
{
    document.getElementById("AdminLoginOverlay").style.height = "0px";
	document.getElementById("okbtn").style.display = "none";
}

function AdminBtn_OnClick() 
{
    document.getElementById("AdminLoginOverlay").style.height = "350px";
}