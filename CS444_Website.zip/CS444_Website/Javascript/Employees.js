function displayItem(n)
{
	for (i=0; i<4; i++)
	{
		if (i == n)
			document.getElementById("item"+i).style.display = "block";
		else
			document.getElementById("item"+i).style.display = "none";
	}
}
function DisplayAddEmployee()
{
	document.getElementById("NameBox").value = "";
	document.getElementById("EmailBox").value = "";
	document.getElementById("PhoneBox").value = "";
	document.getElementById("LanguageBox").value = "";
	document.getElementById("ViewEmpBlock").style.display = "none";
	document.getElementById("AddEmpBlock").style.display = 'block';
}

function SubmitAddEmployee()
{
	var cname = document.getElementById("ENameBox").value;
	var email = document.getElementById("EmailBox").value;
	var phone = document.getElementById("PhoneBox").value;
	var addr = document.getElementById("LanguageBox").value;
	
	xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function()
  	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    	{	
			var str = xmlhttp.responseText;
			
			if (str == "0")	
			{	
				if(confirm("Employee successfully added."))
				{
			    	window.location.reload();  
				}
			}
			else if (str == "1")
			{	
				if(confirm("Employee already exists."))
				{
			    	window.location.reload();  
				}
			}
			else alert("Undefined: " + str);
		}
  	}	

	xmlhttp.open("POST","AddEmployee.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("NameBox="+cname+"&EmailBox="+email+"&PhoneBox="+phone+"&LanguageBox="+encodeURIComponent(lang));	
}