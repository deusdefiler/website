function GetClientsList()
{
	xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function()
  	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    	{			
		  	var Str = xmlhttp.responseText;
			
			var ajaxData = Str.split('#');
						
			var ajaxOptions = ajaxData[1].split('&');
			var selString = "<table>";
			selString += "<tr><th>Name</th><th>Email</th><th>Phone#</th><th>Address</th></tr>\n";	
			for (i=0; i<ajaxData[0]; i++)
			{
				selString += "<tr>\n";	
				var quad = ajaxOptions[i].split(":");
				selString += "<td>" + quad[0] + "</td>\n";	
				selString += "<td>" + quad[1] + "</td>\n";	
				selString += "<td>" + quad[2] + "</td>\n";	
				selString += "<td>" + quad[3] + "</td>\n";	
				selString += "</tr>\n";	
			}	

			selString += "</table>\n";
			document.getElementById("DisplayArea").style.height = "800px";
			document.getElementById("ViewClientsBlock").innerHTML = selString;
			document.getElementById("AddClientBlock").style.display = "none";
			document.getElementById("ViewClientsBlock").style.display = "block";
		}
  	}	

	xmlhttp.open("POST","GetClientInfo.php", true);
	xmlhttp.send("");
}

function DisplayAddClient()
{
	document.getElementById("ClientBox").value = "";
	document.getElementById("EmailBox").value = "";
	document.getElementById("PhoneBox").value = "";
	document.getElementById("AddressBox").value = "";
	document.getElementById("ViewClientsBlock").style.display = "none";
	document.getElementById("AddClientBlock").style.display = 'block';
}

function SubmitAddClient()
{
	var cname = document.getElementById("ClientBox").value;
	var email = document.getElementById("EmailBox").value;
	var phone = document.getElementById("PhoneBox").value;
	var addr = document.getElementById("AddressBox").value;
	
	xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function()
  	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    	{	
			var str = xmlhttp.responseText;
			
			if (str == "0")	
			{	
				if(confirm("Client successfully added."))
				{
			    	window.location.reload();  
				}
			}
			else if (str == "1")
			{	
				if(confirm("Client already exists"))
				{
			    	window.location.reload();  
				}
			}
			else alert("Undefined: " + str);
		}
  	}	

	xmlhttp.open("POST","AddNewClient.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("ClientBox="+cname+"&EmailBox="+email+"&PhoneBox="+phone+"&AddressBox="+encodeURIComponent(addr));	
}
function DisplayAddEmployee()
{
	document.getElementById("NameBox").value = "";
	document.getElementById("EmailBox").value = "";
	document.getElementById("PhoneBox").value = "";
	document.getElementById("LanguageBox").value = "";
	document.getElementById("ViewEmpBlock").style.display = "none";
	document.getElementById("AddEmpBlock").style.display = 'block';
}

function SubmitAddEmployee()
{
	var cname = document.getElementById("ENameBox").value;
	var email = document.getElementById("EmailBox").value;
	var phone = document.getElementById("PhoneBox").value;
	var addr = document.getElementById("LanguageBox").value;
	
	xmlhttp=new XMLHttpRequest();
  	xmlhttp.onreadystatechange=function()
  	{
		if (xmlhttp.readyState==4 && xmlhttp.status==200)
    	{	
			var str = xmlhttp.responseText;
			
			if (str == "0")	
			{	
				if(confirm("Employee successfully added."))
				{
			    	window.location.reload();  
				}
			}
			else if (str == "1")
			{	
				if(confirm("Employee already exists."))
				{
			    	window.location.reload();  
				}
			}
			else alert("Undefined: " + str);
		}
  	}	

	xmlhttp.open("POST","AddEmployee.php", true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send("NameBox="+cname+"&EmailBox="+email+"&PhoneBox="+phone+"&LanguageBox="+encodeURIComponent(lang));	
}