-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 19, 2023 at 02:37 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employees`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `clientId` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(35) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phoneNum` varchar(12) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`clientId`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`clientId`, `name`, `email`, `phoneNum`, `address`) VALUES
(21, 'Jeremy Clarks', 'jc@junk.com', '800-588-2300', '64 18th Avenue, Queens, NY'),
(22, 'Mark Fishbach', 'mfish@iona.edu', '387-644-7000', '22 Hop Lane, Brooklyn, NY'),
(23, 'Celia Simmons', 'cesi@mysite.com', NULL, NULL),
(24, 'Tobias Rieper', 'tobiriep@me.com', '518-260-8899', '48 6th Avenue, New York, NY'),
(25, 'Katherine Bates', 'kbates@site.com', '500-828=2295', '86 North Boulevard, New York, NY'),
(26, 'Dr. Ivanov', 'li@junk.com', NULL, '111 West Street, Noville, NJ 08000');

-- --------------------------------------------------------

--
-- Table structure for table `employeedata`
--

DROP TABLE IF EXISTS `employeedata`;
CREATE TABLE IF NOT EXISTS `employeedata` (
  `empId` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phoneNum` varchar(12) DEFAULT NULL,
  `langId` varchar(15) DEFAULT NULL,
  `projId` varchar(8) DEFAULT NULL,
  `clientId` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`empId`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employeedata`
--

INSERT INTO `employeedata` (`empId`, `name`, `email`, `phoneNum`, `langId`, `projId`, `clientId`) VALUES
(194, 'B. Johnson', 'brijohn27@yahoo.com', '347-555-9000', '001', '00001185', '00021'),
(195, 'N. Brown', 'nbrown@yahoo.com', '347-555-8000', '001,002', '00001186', '00022'),
(196, 'J. Nicols', 'jennynics@yahoo.com', '216-888-6000', '002,003', '00001187', '00023'),
(197, 'A. Kane', 'akane@yahoo.com', '384-555-4500', '003', '00001189', '00024'),
(198, 'J. Hawkins', 'jakeh@yahoo.com', '516-888-3580', '003,005', '00001189', '00024'),
(199, 'K. Greir', 'kellyg@yahoo.com', '516-555-9000', '004', '00001188', '00025');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `langId` int(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `progLangs` text,
  PRIMARY KEY (`langId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`langId`, `progLangs`) VALUES
(1, 'HTML'),
(2, 'Java'),
(3, 'PHP'),
(4, 'Java'),
(5, 'Javascript');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `projId` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `projName` varchar(100) DEFAULT NULL,
  `client` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`projId`)
) ENGINE=InnoDB AUTO_INCREMENT=1201 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`projId`, `projName`, `client`, `status`) VALUES
(1185, 'Exon Site', '00021', 'Completed'),
(1186, 'Private Client Site', '00022', 'Completed'),
(1187, 'Private Client Site', '00023', 'Active'),
(1188, 'Paper Company Site', '00024', 'Active'),
(1189, 'Shell Site Update', '00035', 'Active'),
(1200, 'Iona Website Update', '00026', 'Proposed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `userId` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `password`) VALUES
(1, 'dromine', '70ccd9007338d6d81dd3b6271621b9cf9a97ea00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
