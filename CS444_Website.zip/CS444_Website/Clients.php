<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT clientId, name, email, phoneNum, address FROM clients WHERE clientId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$addressDB = $row["address"];
	$clientIdDB = $row["clientId"];
	
	echo "<html>";
	echo "<head>";
	echo "	<title>Clients</title>";
	echo "		<meta charset='UTF-8'>";
	echo "		<link rel='stylesheet' type='text/css' href='CSS/ClientLayout.css'>";
	echo "		<script language='Javascript' type='text/javascript' src='Javascript/Clients.js'></script>";
	echo "</head>";
	echo "<body>";
	echo "	<div class='titleRegion'>";
	echo "		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href=\"index.php\";'>Back</button>";
  	echo "		<h1>Clients</h1>";
	echo "	</div>";
	
	echo "<div class='clearfix'>";
 	echo "<div class='column menu'>";
    echo "	<ul>";
    echo "  		<li onclick='DisplayAddClient;'>Add Client</li>";
    echo "  		<li onclick='displayItem(1);'>Edit Client</li>";
    echo "	</ul>";
  	echo "</div>";
	$query = "SELECT name, email, phoneNum, address FROM clients";
	$result = $db->query($query);		
	$numRow = $result->num_rows;
	$returnStr = $numRow."#";
	for ($i=0; $i<$numRow; $i++)
	{
		$row = $result->fetch_assoc();
		$returnStr = $returnStr.$row['name'].":".$row['email'].":".$row['phoneNum'].":".$row['address']."&";
	}
	echo $returnStr;
	
	<div id="DisplayArea" class="column info">
		<div class='column info'>
			<div id='ViewClientBlock' class='inputBlock'>
				</div>
	
				<div id='AddClientBlock' class='inputBlock'>
					<div id='ClientSpan'>
						<label class="clientInfoLabel">Name:</label>
						<input type="text" id="NameBox" name="NameBox">
					</div>
					<div>
						<span id='EmailSpan'>
							<label class="clientInfoLabel">Email:</label>
							<input type="email" id="EmailBox" name="EmailBox">
						</span>
						<span id='PhoneSpan'>
							<label class="clientInfoLabel">Phone:</label>
							<input type="text" id="PhoneBox" name="PhoneBox">
						</span>
					</div>
					<div id='AddrSpan'>
						<label>Language:</label><br>
						<textarea id="AddressBox" name="AddressBox" rows="4" cosls="50" style='disabled: true;'></textarea>
					</div>
					<div>
						<button id="AddClientBtn" onclick="SubmitAddClient();">Submit</button>
					</div>
			</div>
		</div>
	</div>
	
	echo "</body>";
	echo "</html>";
?>