<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT clientId, name, email, phoneNum, address FROM clients WHERE clientId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$addressDB = $row["address"];
	$clientIdDB = $row["clientId"];
	
	echo "<html>";
	echo "<head>";
	echo "	<title>Clients</title>";
	echo "		<meta charset='UTF-8'>";
	echo "		<link rel='stylesheet' type='text/css' href='CSS/ClientLayout.css'>";
	echo "		<script language='Javascript' type='text/javascript' src='Javascript/Clients.js'></script>";
	echo "</head>";
	echo "<body>";
	echo "	<div class='titleRegion'>";
	echo "		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href=\"index.php\";'>Back</button>";
  	echo "		<h1>Clients</h1>";
	echo "	</div>";
	
	echo "<div class='clearfix'>";
 	echo "<div class='column menu'>";
    echo "	<ul>";
    echo "  		<li onclick='DisplayAddClient;'>Add Client</li>";
    echo "  		<li onclick='displayItem(1);'>Edit Client</li>";
    echo "	</ul>";
  	echo "</div>";
	$query = "SELECT name, email, phoneNum, address FROM clients";
	$result = $db->query($query);		
	$numRow = $result->num_rows;
	$returnStr = $numRow."#";
	for ($i=0; $i<$numRow; $i++)
	{
		$row = $result->fetch_assoc();
		$returnStr = $returnStr.$row['name'].":".$row['email'].":".$row['phoneNum'].":".$row['address']."&";
	}
	echo $returnStr;
	
	echo " <div id='DisplayArea' class='column info'>";
	echo "	<div class='column info'>";
	echo "		<div id='ViewClientBlock' class='inputBlock'>";
	echo "			</div>";
	
	echo "			<div id='AddClientBlock' class='inputBlock'>";
	echo "				<div id='ClientSpan'>";
	echo "					<label class='clientInfoLabel'>Name:</label>";
	echo "					<input type='text' id='NameBox' name='NameBox'>";
	echo "				</div>";
	echo "				<div>";
	echo "					<span id='EmailSpan'>";
	echo "						<label class='clientInfoLabel'>Email:</label>";
	echo "						<input type=;email; id=;EmailBox; name=;EmailBox;>";
	echo "					</span>";
	echo "					<span id='PhoneSpan'>";
	echo "						<label class='clientInfoLabel'>Phone:</label>";
	echo "						<input type='text' id='PhoneBox' name='PhoneBox'>";
	echo "					</span>";
	echo "				</div>";
	echo "				<div id='AddrSpan'>";
	echo "					<label>Language:</label><br>";
	echo "					<textarea id='AddressBox' name='AddressBox' rows='4' cosls='50' style='disabled: true;'></textarea>";
	echo "				</div>";
	echo "				<div>";
	echo "					<button id='AddClientBtn' onclick='SubmitAddClient();'>Submit</button>";
	echo "				</div>";
	echo "		</div>";
	echo "	</div>";
	echo "</div>";
	
	echo "</body>";
	echo "</html>";
?>