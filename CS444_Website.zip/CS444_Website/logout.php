<?php
	session_start();
	session_unset();
	//unset($_SESSION['userId']);
	session_destroy();
	echo '<script type="text/javascript">';
	echo '		window.location.href="index.php";';
	echo '</script>';
?>