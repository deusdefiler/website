<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT empId, name, email, phoneNum, langId, projId, clientId FROM employeedata WHERE empId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$langDB = $row["langId"];
	$projDB = $row["projId"];
	$clientDB = $row["clientId"];
	$empIdDB = $row["empId"];
	
	echo "<html>";
	echo "<head>";
	echo "	<title>"Employees"</title>";
	echo "		<meta charset='UTF-8'>";
	echo "		<link rel='stylesheet' type='text/css' href='CSS/EmployeeLayout.css'>";
	echo "		<script language='Javascript' type='text/javascript' src='Javascript/Employees.js'></script>";
	echo "</head>";
	echo "<body>";
	echo "	<div class='titleRegion'>";
	echo "		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href=\"index.php\";'>Back</button>";
  	echo "		<h1>"Employees"</h1>";
	echo "	</div>";
	
	echo "<div class='clearfix'>";
 	echo "<div class='column menu'>";
    echo "	<ul>";
    echo "  		<li onclick='DisplayAddEmployee;'>Add Employee</li>";
    echo "  		<li onclick='displayItem(1);'>Edit Employee</li>";
    echo "	</ul>";
  	echo "</div>";
	$query = "SELECT name, email, phoneNum, langId FROM employeedata";
	$result = $db->query($query);		
	$numRow = $result->num_rows;
	$returnStr = $numRow."#";
	for ($i=0; $i<$numRow; $i++)
	{
		$row = $result->fetch_assoc();
		$returnStr = $returnStr.$row['name'].":".$row['email'].":".$row['phoneNum'].":".$row['langId']."&";
	}
	echo $returnStr;
	
	<div id="DisplayArea" class="column info">
		<div class='column info'>
			<div id='ViewEmpBlock' class='inputBlock'>
				</div>
	
				<div id='AddEmpBlock' class='inputBlock'>
					<div id='EmpSpan'>
						<label class="empInfoLabel">Name:</label>
						<input type="text" id="NameBox" name="NameBox">
					</div>
					<div>
						<span id='EmailSpan'>
							<label class="empInfoLabel">Email:</label>
							<input type="email" id="EmailBox" name="EmailBox">
						</span>
						<span id='PhoneSpan'>
							<label class="empInfoLabel">Phone:</label>
							<input type="text" id="PhoneBox" name="PhoneBox">
						</span>
					</div>
					<div id='LangSpan'>
						<label>Language:</label><br>
						<textarea id="LanguageBox" name="LanguageBox" rows="1" cols="50" style='disabled: true;'></textarea>
					</div>
					<div>
						<button id="AddEmployeeBtn" onclick="SubmitAddEmployee();">Submit</button>
					</div>
			</div>
		</div>
	</div>
	
	echo "</body>";
	echo "</html>";
?>