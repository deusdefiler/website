<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT empId, name, email, phoneNum, langId, projId, clientId FROM employeedata WHERE empId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$langDB = $row["langId"];
	$projDB = $row["projId"];
	$clientDB = $row["clientId"];
	$empIdDB = $row["empId"];
	
	echo "<html>";
	echo "<head>";
	echo "	<title>Employees</title>";
	echo "		<meta charset='UTF-8'>";
	echo "		<link rel='stylesheet' type='text/css' href='CSS/EmployeeLayout.css'>";
	echo "		<script language='Javascript' type='text/javascript' src='Javascript/Employees.js'></script>";
	echo "</head>";
	echo "<body>";
	echo "	<div class='titleRegion'>";
	echo "		<button id='BackBtn' type='button' name='BackBtn' onclick='window.location.href=\"index.php\";'>Back</button>";
  	echo "		<h1>Employees</h1>";
	echo "	</div>";
	
	echo "<div class='clearfix'>";
 	echo "<div class='column menu'>";
    echo "	<ul>";
    echo "  		<li onclick='DisplayAddEmployee;'>Add Employee</li>";
    echo "  		<li onclick='displayItem(1);'>Edit Employee</li>";
    echo "	</ul>";
  	echo "</div>";

	echo "<div class='column info'>";
	echo "	<div id='item0'>";
	echo "		<h1>Employees</h1>";
	echo "		<p>";
	for ($i=0; $i<$numRow; $i++)
	{
		$row = $result->fetch_assoc();
		$nameDB = $row["name"];
		$mailDB = $row["email"];
		$phoneDB = $row["phoneNum"];
		$langDB = $row["langId"];
		$projDB = $row["projId"];
		$clientDB = $row["clientId"];
		$empIdDB = $row["empId"];
	}
	echo "	   </p>";
	echo "  </div>";
	echo "</div>";
	
	echo "<div id='DisplayArea' class='column info'>";
	echo "	<div class='column info'>";
	echo "		<div id='ViewEmpBlock' class='inputBlock'>";
	echo "			</div>";
	
	echo "		<div id='AddEmpBlock' class='inputBlock'>";
	echo "				<div id='EmpSpan'>";
	echo "					<label class='empInfoLabel'>Name:</label>";
	echo "					<input type='text' id='NameBox' name='NameBox'>";
	echo "				</div>";
	echo "				<div>";
	echo "					<span id='EmailSpan'>";
	echo "						<label class='empInfoLabel'>Email:</label>";
	echo "						<input type='email' id='EmailBox' name='EmailBox'>";
	echo "					</span>";
	echo "					<span id='PhoneSpan'>";
	echo "						<label class='empInfoLabel'>Phone:</label>";
	echo "						<input type='text' id='PhoneBox' name='PhoneBox'>";
	echo "					</span>";
	echo "				</div>";
	echo "				<div id='LangSpan'>";
	echo "					<label>Language:</label><br>";
	echo "					<textarea id='LanguageBox' name='LanguageBox' rows='1' cols='50' style='disabled: true;'></textarea>";
	echo "				</div>";
	echo "				<div>";
	echo "					<button id='AddEmployeeBtn' onclick='SubmitAddEmployee();'>Submit</button>";
	echo "				</div>";
	echo "		</div>";
	echo "	</div>";
	echo "</div>";
	echo "</div>";
	
	echo "</body>";
	echo "</html>";
?>