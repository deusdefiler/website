<?php
	include("configDB.php");
?>
<!DOCTYPE html>
<?php
	$num = $_GET["num"];
	
	$db = new mysqli($server, $username, $password, $dbName);
	if (mysqli_connect_errno()) { echo "Connection failed!"; exit; }
	
	$query = "SELECT empId, name, email, phoneNum, langId, projId, clientId FROM employeedata WHERE empId=".$num;
	$result = $db->query($query);	
	$numRow = $result->num_rows;
	$row = $result->fetch_assoc();
	$nameDB = $row["name"];
	$mailDB = $row["email"];
	$phoneDB = $row["phoneNum"];
	$langDB = $row["langId"];
	$projDB = $row["projId"];
	$clientDB = $row["projId"];
	$empIdDB = $row["empId"];
	
	
?>